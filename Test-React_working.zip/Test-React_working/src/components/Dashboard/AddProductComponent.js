import React, { useState } from "react";
import Axios from "axios";
import HeaderComponent from './HeaderComponent';
const AddProductComponent = () => {
  const [pName, setPName] = useState("");
  const [pPrice, setPPrice] = useState("");
  const [pModal, setPModal] = useState("");
  const [pDescription, setPDescription] = useState("");
  const [pImage, setPImage] = useState("");

  const handleUploadPImage = (e) => {
    const file = e.target.files[0];
    fileBase64(file);
  };

  const fileBase64 = (file) =>
    new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      console.log("reader?.result");
      reader.onload = () => resolve(setPImage(reader?.result));
      reader.onerror = reject;
    });

  const handleSubmit = (e) => {
    e.preventDefault();
    const requestBody = {
      pName,
      pPrice,
      pModal,
      pDescription,
      pImage,
    };
    Axios.post("http://localhost:3000/product", requestBody).then((result) => {
      alert("Product submitted successfully...");
    });
  };

  return (
    
    <>
      <div className="add-product-form mt-5">
        <form>
          <div className="form-group">
            <label>Product Name</label>
            <input
              type="text"
              className="form-control"
              value={pName}
              name="pName"
              onChange={(e) => setPName(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Product Modal</label>
            <input
              type="text"
              className="form-control"
              value={pModal}
              name="pModal"
              onChange={(e) => setPModal(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Product price</label>
            <input
              type="text"
              className="form-control"
              value={pPrice}
              name="pPrice"
              onChange={(e) => setPPrice(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Product Description</label>
            <input
              type="text"
              className="form-control"
              value={pDescription}
              name="pDescription"
              onChange={(e) => setPDescription(e.target.value)}
            />
          </div>
          <div className="form-group">
            <label>Product Image</label>
            <input
              type="file"
              className="form-control"
              name="pImage"
              accept=".jpg, .jpeg, .png"
              onChange={(e) => handleUploadPImage(e)}
            />
          </div>
          <div className="form-group mt-5">
            <button className="btn btn-primary" onClick={handleSubmit}>
              Submit
            </button>
            <button className="btn btn-secondary ms-3">Clear</button>
          </div>
        </form>
      </div>
    </>
  );
};

export default AddProductComponent;