import React, { Component } from "react";
import { Button, Modal } from "react-bootstrap";

export default class EmpDetailsModal extends Component {
  constructor(props) {
    super(props);
  }
  render() {
    return (
      <>
        <Modal
          show={this.props.isOpenEmpDetailsModal}
          onHide={this.props.closeEmpDetailsModal}
        >
          <Modal.Header closeButton>
            <Modal.Title>Emap Details</Modal.Title>
          </Modal.Header>
          <Modal.Body>
            <div>
              <img className="empPic" src={this.props.empDetails.profileUrl} />
              <p className="">
                <p>{this.props.empDetails.name}</p>
                <span>{this.props.empDetails.salary}</span>
              </p>
            </div>
          </Modal.Body>
          <Modal.Footer>
            <Button
              variant="secondary"
              onClick={this.props.closeEmpDetailsModal}
            >
              Close
            </Button>
            <Button variant="primary" onClick={this.props.closeEmpDetailsModal}>
              Save Changes
            </Button>
          </Modal.Footer>
        </Modal>
      </>
    );
  }
}
