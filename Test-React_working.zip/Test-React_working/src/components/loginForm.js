import React from 'react';
import { Formik } from 'formik';
import { toast } from 'react-toastify';
import { useNavigate } from 'react-router-dom';
import "react-toastify/dist/ReactToastify.css";
const formFun = (navigation) => (
  <div className="container">
    <h1 className="text-primary">Login page</h1>
    <Formik
      initialValues={{ email: '', password: '' }}
      validate={values => {
        const errors = {};
        if (!values.email) {
          errors.email = 'Email id Required';
        } else if (
          !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$/i.test(values.email)
        ) {
          errors.email = 'Invalid email address';
        }

        if (!values.password) {
          {
            errors.password = 'Password Required';
          }

        }
        return errors;
      }}
      onSubmit={(values, { setSubmitting }) => {
        let dbUsername = "india@gmail.com";
        let dbPassword = "pass"
        setTimeout(() => {
          if (dbUsername == values.email && dbPassword == values.password) {
            toast.success("Logged in successfully", {
              position: toast.POSITION.TOP_RIGHT
            });
            navigation("/AddProductComponent");
          } else {
            toast.error("Enter valid credentials", {
              position: toast.POSITION.TOP_RIGHT
            });
          }
          setSubmitting(false);
        }, 100);
      }}
      showSuccess={() => {
        toast.success("Success Notification");
      }
      }
    >
      {({
        values,
        errors,
        touched,
        handleChange,
        handleBlur,
        handleSubmit,
        isSubmitting
        /* and other goodies */
      }) => (
        <form className='form' onSubmit={handleSubmit}>
          <div className="col-md-9">
            <label for="email" className="form-label">Email</label>
            <div className="d-flex"> 
            <input type="email" name="email" className="form-control" onChange={handleChange}
              onBlur={handleBlur}
              value={values.email} />
           <span className='error'> {errors.email && touched.email && errors.email}</span>
           </div>
          </div>
          <div className="col-md-9">
            <label for="password" className="form-label">Password</label>
            <div className="d-flex"> 
            <input type="password" name="password" className="form-control" onChange={handleChange}
              onBlur={handleBlur}
              value={values.password} />
           <span className='error'> {errors.password && touched.password && errors.password}</span>
          </div>
          </div>
          <br></br>
          <button type="submit" className="btn btn-warning" disabled={isSubmitting}>
            Submit
          </button>
        </form>
      )}
    </Formik>
  </div>
);

const Loginform = () => {
  const navigation = useNavigate();
  return <>{formFun(navigation)}</>;
};

export default Loginform;