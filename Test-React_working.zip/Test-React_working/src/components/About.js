import React, { Component } from 'react'

export default class About extends Component {
  render() {
    return (
      <h1>
        welcome to All products
      </h1>
    )
  }
}