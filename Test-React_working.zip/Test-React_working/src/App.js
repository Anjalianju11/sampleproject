import React,{Component,useState,useEffect} from 'react';
import {useSelector} from "react-redux";
import { ToastContainer } from 'react-toastify';
import "react-toastify/dist/ReactToastify.css";
import 'bootstrap/dist/css/bootstrap.min.css';
import Loginform from './components/loginForm';
import { Routes, Route, useLocation, BrowserRouter } from 'react-router-dom';
import AddProductComponent from './components/Dashboard/AddProductComponent';
import HeaderComponent from './components/Dashboard/HeaderComponent';
import About from './components/About';
import EmployeDetails from './components/Dashboard/EmployeDetails';
//import HeaderComponent from './components/AddProductComponent/HeaderComponent';
const App = () => {
const routpath=useLocation();
  return (
      <>
      {(routpath.pathname =="/" || routpath.pathname =="/login") ? null:<HeaderComponent/>}
        <ToastContainer />
        <Routes>
          <Route path="/login" element={<Loginform />} />
          <Route path="/" element={<Loginform />} />
          <Route path="/AddProductComponent" element={<AddProductComponent />} />
          <Route path="/About" element={<About />} />
          <Route path="/EmployeDetails" element={<EmployeDetails />} />

        </Routes>
      
    </>
  );
}
export default App;